<?php

namespace ACA\GravityForms\Field;

interface Multiple extends Options {

	/**
	 * @return bool
	 */
	public function is_multiple();

}