<?php

namespace ACA\GravityForms;

interface MetaTypes {

	public const GRAVITY_FORMS_ENTRY = 'gravity_forms_entry';

}