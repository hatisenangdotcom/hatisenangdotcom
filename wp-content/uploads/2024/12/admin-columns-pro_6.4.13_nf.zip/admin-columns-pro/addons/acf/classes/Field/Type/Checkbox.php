<?php

namespace ACA\ACF\Field\Type;

use ACA\ACF\Field;

class Checkbox extends Field implements Field\Choices {

	use ChoicesTrait;
}