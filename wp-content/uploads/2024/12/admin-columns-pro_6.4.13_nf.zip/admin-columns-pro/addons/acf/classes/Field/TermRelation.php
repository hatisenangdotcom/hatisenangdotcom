<?php

namespace ACA\ACF\Field;

interface TermRelation {

	/**
	 * @return array
	 */
	public function uses_native_term_relation();

}