function copyToField(el){
  var text = el.getAttribute('data-link'),
      textarea = document.getElementById('rujukanField'),
      textareaValue = textarea.value,
      Regex = new RegExp(text + '\n', 'g'),            // make new regex with <a> text and \n line break 
      textareaValue = textareaValue.indexOf(text+'\n') > -1 ?  textareaValue.replace(Regex, '') : textareaValue + text+'\n'; // this is something similar to if statement .. mean if the textarea has the <a> text and after it line break .. replace it with its line break to blank (remove it) .. if not its not on textarea add this <a> text to the textarea value
      textarea.value = textareaValue;
  // Toggle button text
  if (el.innerHTML == "Pilih") {
    el.innerHTML = "Hapus";
  } else {
    el.innerHTML = "Pilih";
  }
}

var app = new Vue({
  el : '#app',
  data : function(){
    loading = true;
    return {
      searchQuery : '',
      sources : [
        {
          name: 'Tafsir',
          on: true,
          url : 'https://pustaka.hatisenang.com/wp-json/wp/v2/downloads?filter[category]=tafsir?per_page=3',
          posts : []
        },
        {
          name: 'Blog',
          on: true,
          url : 'https://pustaka.hatisenang.com/wp-json/wp/v2/posts?per_page=3',
          posts : []
        }
      ]
    }
  },
  
  filters: {
    dformatLink: function (value) {
    return value.replace(/\?post_type=dlm_download&p=/, 'download\/');
  },
    // Convert post date to a readable format
    formatDate: function (date_str) {
      var year = date_str.substr(0,4),
          month = parseInt(date_str.substr(5,2)),
          day = date_str.substr(8,2),
          months = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return months[month] + " " + day + ", "+year;
    }
  },
  
  methods: {
    // Load all posts from separate APIs
    loadPosts : function(){
      var self = this;
      self.loading = true;
      self.sources.forEach(function(source, index){
        self.$delete(source, 'posts');
        //Verify that source should be displayed
        if(source.on){
          var searchUrl = self.generateUrl(source);
          // Get API with vue-resource     
          self.$http.get(searchUrl).then(function(response)  {
            self.$set(source, 'posts', response.data, self.loading = false);
          }, function(response) {
            console.log('Error');
          });
        }
      });
    },
    
    // Generate the search URL
    generateUrl : function(source){
      var self = this;
      // Add search parameters.
      if(self.searchQuery){
        return source.url + '&search=' + encodeURI(self.searchQuery);
      }else{
        return source.url;
      }      
    }
  },
  
  mounted : function(){
    this.$nextTick(function(){
      // Load posts on initial page load
      this.loadPosts();
    });
  }
});